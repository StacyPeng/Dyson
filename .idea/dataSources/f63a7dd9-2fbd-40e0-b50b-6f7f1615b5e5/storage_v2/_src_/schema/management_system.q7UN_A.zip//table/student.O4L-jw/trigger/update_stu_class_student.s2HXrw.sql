create definer = Hengqian@`%` trigger update_stu_class_student
    after update
    on student
    for each row
BEGIN
    UPDATE stu_class
    SET student_email_address = NEW.student_email_address
    WHERE student_email_address = OLD.student_email_address;
END;

