create definer = root@localhost trigger update_Exames_Modules
    after update
    on modules
    for each row
BEGIN
    UPDATE Exames SET modId = NEW.modId WHERE examId = NEW.examId;
END;

