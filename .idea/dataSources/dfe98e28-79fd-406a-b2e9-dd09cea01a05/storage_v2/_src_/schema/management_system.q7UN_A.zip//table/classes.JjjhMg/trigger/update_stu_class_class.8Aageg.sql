create definer = Hengqian@`%` trigger update_stu_class_class
    after update
    on classes
    for each row
BEGIN
    UPDATE stu_class
    SET class_id = NEW.class_id
    WHERE class_id = OLD.class_id;
END;

